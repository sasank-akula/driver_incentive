sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.cy.driverincentiveui.controller.App", {
      onInit() {
      }
  });
});
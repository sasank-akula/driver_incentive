sap.ui.define(
  [
    "sap/ui/core/mvc/Controller"
  ],
  function (BaseController) {
    "use strict";

    return BaseController.extend("com.driver.workflowui.controller.App", {
      onInit() {
      },
      onAfterRendering: async function () {
        debugger
        console.log(window.location);
        if (window?.location?.hash.includes("TaskCollection")) {
          setTimeout(() => {
            var oContextData = this.getOwnerComponent().getModel("context").getData();
            this._oID = oContextData.complaint_id;
            console.log("Complaint", this._oID);
          }, 1000);
        }
        let oModel = this.getOwnerComponent().getModel("NorthWindModel");
        debugger
        try {
        let oBinding = oModel.bindList("/Products", null, null, null, {
            $expand: "Category,Supplier"
        });

        let aContexts = await oBinding.requestContexts();
        let aProducts = aContexts.map(ctx => ctx.getObject());

        console.log("Expanded Products with Category & Supplier:", aProducts);

    } catch (err) {
        console.error("Error fetching Products:", err);
    }
        // this.getModel("IncentiveHeaderModel").setData(oDetail)
        // this.getModel("IncentiveItemModel").setProperty("/items", oDetail.IncentiveDetailAss);
        // this.getModel("IncentiveSummaryModel").setProperty("/items", oDetail.IncentiveSummaryAss);
      }
    });
  }
);
